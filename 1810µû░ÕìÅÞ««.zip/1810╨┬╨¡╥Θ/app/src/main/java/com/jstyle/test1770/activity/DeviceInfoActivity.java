package com.jstyle.test1770.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.SwitchCompat;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.jstyle.blesdk.Util.BleSDK;
import com.jstyle.blesdk.constant.BleConst;
import com.jstyle.blesdk.constant.DeviceKey;
import com.jstyle.blesdk.model.MyDeviceInfo;
import com.jstyle.test1770.R;


import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DeviceInfoActivity extends BaseActivity {

    @BindView(R.id.button_reset)
    Button buttonReset;
    @BindView(R.id.button_battery)
    Button buttonBattery;
    @BindView(R.id.button_mac)
    Button buttonMac;
    @BindView(R.id.button_read_version)
    Button buttonReadVersion;
    @BindView(R.id.button_mcu_rest)
    Button buttonMcuRest;
    @BindView(R.id.radio_12h)
    RadioButton radio12h;
    @BindView(R.id.radio_24h)
    RadioButton radio24h;
    @BindView(R.id.radioGroup1)
    RadioGroup radioGroupTimeMode;
    @BindView(R.id.radio_km)
    RadioButton radioKm;
    @BindView(R.id.radio_mile)
    RadioButton radioMile;
    @BindView(R.id.radioGroup3)
    RadioGroup radioGroup_distanceUnit;
    @BindView(R.id.SwitchCompat_hand)
    SwitchCompat SwitchCompatHand;
    @BindView(R.id.radio_lefthand)
    RadioButton radioLefthand;
    @BindView(R.id.radio_righthand)
    RadioButton radioRighthand;
    @BindView(R.id.radioGroup_hand)
    RadioGroup radioGroupHand;
    @BindView(R.id.radio_display_v)
    RadioButton radioDisplayV;
    @BindView(R.id.radio_display_h)
    RadioButton radioDisplayH;
    @BindView(R.id.radioGroup_display)
    RadioGroup radioGroupDisplay;
    @BindView(R.id.button_deviceinfo_set)
    Button buttonDeviceinfoSet;
    @BindView(R.id.button_deviceinfo_get)
    Button buttonDeviceinfoGet;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_info);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.button_reset, R.id.button_battery, R.id.button_mac, R.id.button_read_version, R.id.button_mcu_rest, R.id.button_deviceinfo_set, R.id.button_deviceinfo_get})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.button_reset:
                showResetDialog();

                break;
            case R.id.button_battery:
                sendValue(BleSDK.GetDeviceBatteryLevel());
                break;
            case R.id.button_mac:
                sendValue(BleSDK.GetDeviceMacAddress());
                break;
            case R.id.button_read_version:
                sendValue(BleSDK.GetDeviceVersion());
                break;
            case R.id.button_mcu_rest:
                sendValue(BleSDK.MCUReset());
                break;
            case R.id.button_deviceinfo_set:
                setDeviceInfo();
                break;
            case R.id.button_deviceinfo_get:
                sendValue(BleSDK.GetDeviceInfo());
                break;
        }
    }

    private void showResetDialog() {
        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.Restore_factory))
                .setMessage(getString(R.string.Restore_factory_tips))
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        sendValue(BleSDK.Reset());
                    }
                })
                .setNegativeButton("Cancel",null)
                .create().show();

    }

    private void setDeviceInfo() {
        MyDeviceInfo deviceBaseParameter=new MyDeviceInfo();
        deviceBaseParameter.setDistanceUnit(radioGroup_distanceUnit.getCheckedRadioButtonId()==R.id.radio_mile);
        deviceBaseParameter.setHandleState(radioGroupHand.getCheckedRadioButtonId()==R.id.radio_lefthand);
        deviceBaseParameter.setRainHandEnable(SwitchCompatHand.isChecked());
        deviceBaseParameter.setScreenState(radioGroupDisplay.getCheckedRadioButtonId()==R.id.radio_display_h);
        deviceBaseParameter.setShowHour(radioGroupTimeMode.getCheckedRadioButtonId()==R.id.radio_12h);
        //deviceBaseParameter.setBaseHeart(10);
        sendValue(BleSDK.SetDeviceInfo(deviceBaseParameter));
    }

    @Override
    public void dataCallback(Map<String, Object> maps) {
        super.dataCallback(maps);
        String dataType= getDataType(maps);
        Map<String,String>data= getData(maps);
        switch (dataType){
            case BleConst.GetDeviceBatteryLevel:
                String battery=data.get(DeviceKey.BatteryLevel);
                showDialogInfo(battery);
                break;
            case BleConst.GetDeviceMacAddress:
                String mac=data.get(DeviceKey.MacAddress);
                showDialogInfo(mac);
                break;
            case BleConst.GetDeviceVersion:
                String version=data.get(DeviceKey.DeviceVersion);
                showDialogInfo(version);
                break;
            case BleConst.GetDeviceInfo:
                int timeMode= Integer.parseInt(data.get(DeviceKey.TimeUnit));
                int distanceUnit= Integer.parseInt(data.get(DeviceKey.DistanceUnit));
                int handEnable= Integer.parseInt(data.get(DeviceKey.WristOn));
                int handState= Integer.parseInt(data.get(DeviceKey.LeftOrRight));
                int displayMode= Integer.parseInt(data.get(DeviceKey.ScreenShow));
                radioGroupTimeMode.check(timeMode==1?R.id.radio_12h:R.id.radio_24h);
                radioGroupDisplay.check(displayMode==1?R.id.radio_display_h:R.id.radio_display_v);
                radioGroup_distanceUnit.check(distanceUnit==1?R.id.radio_mile:R.id.radio_km);
                radioGroupHand.check(handState==1?R.id.radio_lefthand:R.id.radio_righthand);
                SwitchCompatHand.setChecked(handEnable==1);
                break;
        }
    }
}
