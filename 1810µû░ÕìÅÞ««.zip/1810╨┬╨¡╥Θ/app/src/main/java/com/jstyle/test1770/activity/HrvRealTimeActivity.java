package com.jstyle.test1770.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.jstyle.blesdk.Util.BleSDK;
import com.jstyle.blesdk.cmdenum.SendCmdState;
import com.jstyle.blesdk.constant.BleConst;
import com.jstyle.blesdk.constant.DeviceKey;
import com.jstyle.blesdk.model.ControlHRV;
import com.jstyle.test1770.R;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindColor;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import lecho.lib.hellocharts.gesture.ContainerScrollType;
import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.Viewport;

public class HrvRealTimeActivity extends BaseActivity {


    @BindView(R.id.bt_hrvRealTime_start)
    Button btHrvRealTimeStart;
    @BindView(R.id.tv_hrv_testProgress)
    TextView tvHrvTestProgress;
    @BindView(R.id.tv_hrv_testHeartWidth)
    TextView tvHrvTestHeartWidth;
    @BindView(R.id.tv_hrv_testHeartValue)
    TextView tvHrvTestHeartValue;
    @BindView(R.id.tv_blood_testProgress)
    TextView tvBloodTestProgress;
    @BindView(R.id.tv_blood_ppg)
    TextView tvBloodPpg;
    @BindView(R.id.tv_blood_width)
    TextView tvBloodWidth;
    @BindView(R.id.tv_blood_reslut_per)
    TextView tvBloodReslutPer;
    @BindView(R.id.tv_blood_reslut_avgHeight)
    TextView tvBloodReslutAvgHeight;
    @BindView(R.id.tv_blood_reslut_maxHeight)
    TextView tvBloodReslutMaxHeight;
    @BindView(R.id.tv_blood_reslut_level)
    TextView tvBloodReslutLevel;
    @BindView(R.id.tv_hrv_reslut_sdnn)
    TextView tvHrvReslutSdnn;
    @BindView(R.id.tv_hrv_reslut_sdnn_avg)
    TextView tvHrvReslutSdnnAvg;
    @BindView(R.id.tv_hrv_reslut_total)
    TextView tvHrvReslutTotal;
    @BindView(R.id.tv_hrv_reslut_count)
    TextView tvHrvReslutCount;
    @BindView(R.id.tv_hrv_reslut_tired)
    TextView tvHrvReslutTired;
    @BindView(R.id.tv_hrv_reslut_heartValue)
    TextView tvHrvReslutHeartValue;
    @BindView(R.id.radio_hrv_hand)
    RadioButton radioHrvHand;
    @BindView(R.id.radio_hrv_hand_move)
    RadioButton radioHrvHandMove;
    @BindView(R.id.radioGroup_move)
    RadioGroup radioGroupMove;
    @BindView(R.id.radio_outHand)
    RadioButton radioOutHand;
    @BindView(R.id.radio_onHand)
    RadioButton radioOnHand;
    @BindView(R.id.radioGroup_hand)
    RadioGroup radioGroupHand;
    @BindView(R.id.LineChartView)
    lecho.lib.hellocharts.view.LineChartView LineChartView;
    @BindColor(R.color.colorPrimary)
    int colorAxis;

    static int viewPortRight = 1200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hrv_real_time);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        Viewport viewport = new Viewport(LineChartView.getMaximumViewport());
        viewport.top = 10000;
        viewport.left = 0;
        viewport.bottom = 0;
        viewport.right = viewPortRight;
        LineChartView.setViewportCalculationEnabled(false);
        LineChartView.setMaximumViewport(viewport);
        LineChartView.setCurrentViewport(viewport,false);
        LineChartView.setZoomEnabled(true);
        LineChartView.setContainerScrollEnabled(true, ContainerScrollType.HORIZONTAL);
        LineChartView.setZoomType(ZoomType.HORIZONTAL);
        setLineChartData("");
//        Timer timer=new Timer();
//        TimerTask timerTask=new TimerTask() {
//            @Override
//            public void run() {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        StringBuffer stringBuffer=new StringBuffer();
//                        Random random=new Random();
//                        for(int i=0;i<10;i++){
//                            stringBuffer.append(random.nextInt(5000)+",");
//                        }
//                        String data=stringBuffer.toString();
//                        setLineChartData(data.substring(0,data.length()-1));
//                    }
//                });
//            }
//        };
//        timer.schedule(timerTask,0,500);
    }

    @Override
    public void dataCallback(Map<String, Object> data) {
        super.dataCallback(data);
        String dataType= getDataType(data);
        Map<String,String>maps= getData(data);
        switch (dataType){
            case BleConst.HrvTest:


                String hrvTestProgress = maps.get(DeviceKey.KHrvTestProgress);
                String hrvTestWidth = maps.get(DeviceKey.KHrvTestWidth);
                String hrvTestHeartValue = maps.get(DeviceKey.KHrvTestValue);
                String bloodTestProgress = maps.get(DeviceKey.KBloodTestProgress);
                String bloodTestPPG = maps.get(DeviceKey.KBloodTestValue);
                String bloodTestWidth = maps.get(DeviceKey.KBloodTestCurve);
                String bloodResultPercent = maps.get(DeviceKey.KBloodResultPercent);
                String bloodResultAvgHeight = maps.get(DeviceKey.KBloodResultRebound);
                String bloodResultMaxHeight = maps.get(DeviceKey.KBloodResultMax);
                String bloodResultLevel = maps.get(DeviceKey.KBloodResultRank);
                String hrvResultSDNN = maps.get(DeviceKey.KHrvResultState);
                String hrvResultSDNNAvg = maps.get(DeviceKey.KHrvResultAvg);
                String hrvResultSDNNTotal = maps.get(DeviceKey.KHrvResultTotal);
                String hrvResultCount = maps.get(DeviceKey.KHrvResultCount);
                String hrvResultTried = maps.get(DeviceKey.KHrvResultTired);
                String hrvResultHeartValue = maps.get(DeviceKey.KHrvResultValue);
                int DisturbState = Integer.parseInt(maps.get(DeviceKey.KDisturbState));
                int SlipHand = Integer.parseInt(maps.get(DeviceKey.KSlipHand));
                String PPGData = maps.get(DeviceKey.KPPGData);
                setLineChartData(PPGData);
                tvHrvTestProgress.setText(hrvTestProgress);
                tvHrvTestHeartWidth.setText(hrvTestWidth);
                tvHrvTestHeartValue.setText(hrvTestHeartValue);
                tvBloodTestProgress.setText(bloodTestProgress);
                tvBloodPpg.setText(bloodTestPPG);
                tvBloodWidth.setText(bloodTestWidth);
                tvBloodReslutPer.setText(bloodResultPercent);
                tvBloodReslutAvgHeight.setText(bloodResultAvgHeight);
                tvBloodReslutMaxHeight.setText(bloodResultMaxHeight);
                tvBloodReslutLevel.setText(bloodResultLevel);
                tvHrvReslutSdnn.setText(hrvResultSDNN);
                tvHrvReslutSdnnAvg.setText(hrvResultSDNNAvg);
                tvHrvReslutTotal.setText(hrvResultSDNNTotal);
                tvHrvReslutCount.setText(hrvResultCount);
                tvHrvReslutTired.setText(hrvResultTried);
                tvHrvReslutHeartValue.setText(hrvResultHeartValue);
                radioGroupMove.check(DisturbState == 1 ? R.id.radio_hrv_hand_move : R.id.radio_hrv_hand);
                radioGroupHand.check(SlipHand == 1 ? R.id.radio_onHand : R.id.radio_outHand);
                break;
        }
    }

    List<Integer> queueHeart = new ArrayList<>();

    private void setLineChartData(String ppg) {
        String[] source = null;
        if (!TextUtils.isEmpty(ppg)) {
            source = ppg.split(",");
        }
        if (source != null) {
            for (int i = 0; i < source.length; i++) {
                int size = queueHeart.size();
                if (size >= viewPortRight) queueHeart.remove(0);
                queueHeart.add(Integer.valueOf(source[i]));
            }
        }
        List<PointValue> values = new ArrayList<PointValue>();
        List<AxisValue> axisValuesX = new ArrayList<AxisValue>();
        List<AxisValue> axisValuesY = new ArrayList<AxisValue>();
        LineChartData lineChartData = new LineChartData();
        int size = queueHeart.size();
        for (int i = 0; i < viewPortRight; i++) {
            if (i == size) break;
            values.add(new PointValue(i, queueHeart.get(i)));
        }
        for (int i = 0; i < 7; i++) {
            axisValuesX.add(new AxisValue(i * 200).setLabel((i + "s")
                    .toCharArray()));
        }
        for (int i = 1; i < 4; i++) {
            axisValuesY.add(new AxisValue(i * 3000).setLabel(String.valueOf(i * 3000 + "").toCharArray()));
        }
        Line line = new Line(values);
        line.setColor(colorAxis);
        line.setCubic(true);
        line.setStrokeWidth(2);
        line.setHasPoints(false);
        List<Line> lines = new ArrayList<Line>();
        lines.add(line);
        lineChartData = new LineChartData(lines);
        lineChartData.setAxisXBottom(new Axis().setTextColor(colorAxis)
                .setTextSize(10)
                .setHasLines(true)
                .setValues(axisValuesX));
        lineChartData.setAxisYLeft(new Axis().setValues(axisValuesY)
                .setTextSize(10)
                .setMaxLabelChars(5)
                .setHasLines(true)
                .setTextColor(colorAxis));
        lineChartData.setAxisYRight(new Axis().setValues(axisValuesY).setTextSize(10)
                .setMaxLabelChars(5)
                .setHasLines(true)
                .setTextColor(colorAxis));
        LineChartView.setLineChartData(lineChartData);
    }

    boolean isStart;

    @OnClick(R.id.bt_hrvRealTime_start)
    public void onViewClicked() {
        isStart = !isStart;
        btHrvRealTimeStart.setText(isStart ? "Stop" : "Start");
        ControlHRV controlHRV = new ControlHRV();
        controlHRV.setHrvState(isStart);
        sendValue(BleSDK.HRVData(controlHRV));
    }
}
