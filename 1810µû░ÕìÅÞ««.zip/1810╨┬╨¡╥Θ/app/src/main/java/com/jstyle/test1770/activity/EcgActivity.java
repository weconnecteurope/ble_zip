package com.jstyle.test1770.activity;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.jstyle.blesdk.Util.ResolveUtil;
import com.jstyle.test1770.R;
import com.jstyle.test1770.Util.BleData;
import com.jstyle.test1770.Util.ChartDataUtil;
import com.jstyle.test1770.Util.EcgGraphicView;
import com.jstyle.test1770.Util.RxBus;
import com.jstyle.test1770.ble.BleManager;
import com.jstyle.test1770.ble.BleService;
import com.neurosky.AlgoSdk.NskAlgoDataType;
import com.neurosky.AlgoSdk.NskAlgoECGValueType;
import com.neurosky.AlgoSdk.NskAlgoProfile;
import com.neurosky.AlgoSdk.NskAlgoSampleRate;
import com.neurosky.AlgoSdk.NskAlgoSdk;
import com.neurosky.AlgoSdk.NskAlgoType;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import lecho.lib.hellocharts.view.LineChartView;

import static com.jstyle.blesdk.Util.ResolveUtil.crcValue;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OnFragmentInteractionListener} interface
 * to handle interaction events.
 * <p>
 * create an instance of this fragment.
 */
public class EcgActivity extends AppCompatActivity {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    @BindView(R.id.textView_ecg_hr)
    TextView textViewEcgHr;
    @BindView(R.id.textView_ecg_hrv)
    TextView textViewEcgHrv;
    @BindView(R.id.textView_ecg_bp)
    TextView textViewEcgBp;
    @BindView(R.id.textView_ecg_breath)
    TextView textViewEcgBreath;
    @BindView(R.id.iv_change_display)
    ImageView ivChangeDisplay;
    @BindView(R.id.lineChartView_ppg)
    LineChartView lineChartViewPpg;
    @BindView(R.id.lineChartView_ecg)
    LineChartView lineChartViewEcg;
    Unbinder unbinder;
    @BindView(R.id.button_hrv_level)
    Button buttonHrvLevel;
    @BindView(R.id.button3)
    Button button3;
    @BindView(R.id.button7)
    Button button7;
    @BindView(R.id.button8)
    Button button8;
    @BindView(R.id.bt_startEcg)
    Button btStartEcg;
    @BindView(R.id.tv_ppg)
    TextView tvPpg;
    @BindView(R.id.tv_ecg)
    TextView tvEcg;
    int maxSize = 1536;
    int maxPpgSize = 1200;
    @BindView(R.id.EcgGraphicView)
    com.jstyle.test1770.Util.EcgGraphicView EcgGraphicView;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;
    private Dialog tipsDialog;
    private NskAlgoSdk nskAlgoSdk;
    private Disposable subscription;
    private int currentSelectedAlgo;
    private int activeProfile = -1;

    public EcgActivity() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment EcgFragment.
     */
    // TODO: Rename and change types and number of parameters


    private static final String TAG = "EcgFragment";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_ecg);
        unbinder = ButterKnife.bind(this);
        //showTipsDialog();
        subscribeEcg();
        init();
    }

//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        View view = inflater.inflate(R.layout.fragment_ecg, container, false);
//        unbinder = ButterKnife.bind(this, view);
//        showTipsDialog();
//        subscribeEcg();
//        init();
//        return view;
//    }


    private int index = 0;

    private void init() {
        // DisplayMetrics metrics = getActivity().getResources().getDisplayMetrics();
        // maxSize = metrics.widthPixels;
        nskAlgoSdk = new NskAlgoSdk();
        nskAlgoSdk.setOnECGAlgoIndexListener(new NskAlgoSdk.OnECGAlgoIndexListener() {
            @Override
            public void onECGAlgoIndex(int type, final int value) {
                Log.i(TAG, "onECGAlgoIndex: " + value);
                switch (type) {
                    case NskAlgoECGValueType.NSK_ALGO_ECG_VALUE_TYPE_SMOOTH:
                        //   if (queueEcg.size() > maxSize) queueEcg.remove(0);
                        queueEcg.add(value);
                        index++;
                        //runOnUiThread(new Runnable() {
                           // @Override
                        //    public void run() {
                        EcgGraphicView.setValue(value);
                      //      }
                      //  });
                        if (index > 200) {
                            index = 0;


                        }

                        break;
                    case NskAlgoECGValueType.NSK_ALGO_ECG_VALUE_TYPE_HR:
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textViewEcgHr.setText(String.valueOf(value));
                            }
                        });

                        break;
                    case NskAlgoECGValueType.NSK_ALGO_ECG_VALUE_TYPE_HRV:
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textViewEcgHrv.setText(String.valueOf(value));
                            }
                        });

                        break;
                }
            }
        });

        loadsetup();
        setAlgos();

        initLineChartView();
    }

    private void setAlgos() {
        Log.i(TAG, "setAlgos: " + license);
        String path = getFilesDir().getAbsolutePath();
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_HRVFD;
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_HRVTD;
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_HRV;
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_SMOOTH;
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_HEARTAGE;
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_HEARTRATE;
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_MOOD;
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_RESPIRATORY;
        currentSelectedAlgo |= NskAlgoType.NSK_ALGO_TYPE_ECG_STRESS;
        int ret = nskAlgoSdk.NskAlgoInit(currentSelectedAlgo, path, license);
        if (ret == 0) {
            Log.i(TAG, "setAlgos: Algo SDK has been initialized successfully");
        } else {
            Log.i(TAG, "Failed to initialize the SDK, code = " + String.valueOf(ret));
            return;
        }
        boolean b = nskAlgoSdk.setBaudRate(NskAlgoDataType.NSK_ALGO_DATA_TYPE_ECG, NskAlgoSampleRate.NSK_ALGO_SAMPLE_RATE_512);
        if (b != true) {
            Log.i(TAG, "setAlgos: Failed to set the sampling rate");
            return;
        }
        NskAlgoProfile[] profiles = nskAlgoSdk.NskAlgoProfiles();
        if (profiles.length == 0) {
            // create a default profile
            try {
                String dobStr = "1995-1-1";
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                Date dob = df.parse(dobStr);

                NskAlgoProfile profile = new NskAlgoProfile();
                profile.name = "bob";
                profile.height = 170;
                profile.weight = 80;
                profile.gender = false;
                profile.dob = dob;
                if (nskAlgoSdk.NskAlgoProfileUpdate(profile) == false) {
                    Log.d(TAG, "fail to setup the profile");
                }

                profiles = nskAlgoSdk.NskAlgoProfiles();
                // setup the ECG config
                // assert(nskAlgoSdk.NskAlgoSetECGConfigAfib((float)3.5) == true);
                assert (nskAlgoSdk.NskAlgoSetECGConfigStress(30, 30) == true);
                assert (nskAlgoSdk.NskAlgoSetECGConfigHeartage(30) == true);
                assert (nskAlgoSdk.NskAlgoSetECGConfigHRV(30) == true);
                assert (nskAlgoSdk.NskAlgoSetECGConfigHRVTD(30, 30) == true);
                assert (nskAlgoSdk.NskAlgoSetECGConfigHRVFD(30, 30) == true);

                // nskAlgoSdk.setSignalQualityWatchDog((short)20, (short)5);
                // retrieve the baseline data
                if (profiles.length > 0) {
                    activeProfile = profiles[0].userId;
                    nskAlgoSdk.NskAlgoProfileActive(activeProfile);
                    SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
                    String stringArray = settings.getString("ecgbaseline", null);
                    if (stringArray != null) {
                        String[] split = stringArray.substring(1, stringArray.length() - 1).split(", ");
                        byte[] array = new byte[split.length];
                        for (int i = 0; i < split.length; ++i) {
                            array[i] = Byte.parseByte(split[i]);
                        }
                        if (nskAlgoSdk.NskAlgoProfileSetBaseline(activeProfile, NskAlgoType.NSK_ALGO_TYPE_ECG_HEARTRATE, array) != true) {
                            Log.d(TAG, "error in setting the profile baseline");
                        }
                    }
                }

            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

    }

    Disposable ecgDisposable;

    private void startEcgTimer() {
        if (ecgDisposable != null && !ecgDisposable.isDisposed()) return;
        ;
        Observable.interval(150, TimeUnit.MILLISECONDS).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<Long>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        ecgDisposable = d;
                    }

                    @Override
                    public void onNext(Long value) {
                        //Log.i(TAG, "onNext: "+value);
                        setLineChartViewEcgValue();
                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    private void initLineChartView() {
        ChartDataUtil.initDataChartView(lineChartViewEcg, 0, 8000, maxSize, -8000);
    }

    private void initPPgView(int top, int bottom) {
        //  ChartDataUtil.initDataChartView(lineChartViewPpg, 0, 10000, maxSize, -10000);
        setLineChartViewPpgValue();
    }

    List<Integer> queueEcg = new ArrayList<>();
    List<Integer> queuePpg = new ArrayList<>();

    private void setLineChartViewEcgValue() {
        lineChartViewEcg.setLineChartData(ChartDataUtil.getEcgLineChartData(this, queueEcg, Color.RED));
    }

    private void setLineChartViewPpgValue() {
        lineChartViewPpg.setLineChartData(ChartDataUtil.getPpgLineChartData(this, queuePpg, Color.RED));
    }

    protected void subscribeEcg() {
        subscription = RxBus.getInstance().toObservable(BleData.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<BleData>() {
            @Override
            public void accept(BleData bleData) throws Exception {
                String action = bleData.getAction();
                if (action.equals(BleService.ACTION_DATA_AVAILABLE)) {
                    byte[] value = bleData.getValue();
                    resolveData(value);
                }

            }
        });
    }

    int raw_data_index = 0;
    int maxPPG = 0;
    int minPPg = 33000;

    private void resolveData(byte[] value) {

        switch (value[0]) {
            case (byte) 0xaa:
                Log.i(TAG, "resolveData: "+value.length);
                // Log.i(TAG, "resolveData: "+ ResolveData.byte2Hex(value));
                if (raw_data_index == 0 || raw_data_index % 200 == 0) {
                    // send the good signal for every half second
                    short pqValue[] = {(short) 200};
                    nskAlgoSdk.NskAlgoDataStream(NskAlgoDataType.NSK_ALGO_DATA_TYPE_ECG_PQ, pqValue, 1);
                }
                for (int i = 0; i < value.length / 2 - 1; i++) {
                    int ecgValue = ResolveUtil.getValue(value[i * 2 + 1], 1) + ResolveUtil.getValue(value[i * 2 + 2], 0);
                    if (ecgValue >= 32768) ecgValue = ecgValue - 65536;
                    raw_data_index++;
                    short[] ecgData = new short[]{(short) -ecgValue};
                    nskAlgoSdk.NskAlgoDataStream(NskAlgoDataType.NSK_ALGO_DATA_TYPE_ECG, ecgData, 1);
                }
                break;
            case (byte) 0xab:
                for (int i = 0; i < value.length / 2 - 1; i++) {
                    int ppgValue = ResolveUtil.getValue(value[i * 2 + 1], 1) + ResolveUtil.getValue(value[i * 2 + 2], 0);
                    maxPPG = Math.max(maxPPG, ppgValue);
                    minPPg = Math.min(minPPg, ppgValue);
                    if (ppgValue >= 32768) ppgValue = ppgValue - 65536;
                    if (queuePpg.size() > maxPpgSize) queuePpg.remove(0);
                    queuePpg.add(ppgValue);
                }
                initPPgView(maxPPG, minPPg);
                break;
            case (byte) 0x9c:
                if (value[1] != (byte) 0xff && value[1] != 0x01) changeChartVisibility(false);
                break;
        }
    }

    private short[] byteArray2ShortArray(byte[] data) {
        short[] retVal = new short[data.length / 2];
        for (int i = 0; i < retVal.length; i++)
            retVal[i] = (short) ((data[i * 2] & 0xff) << 8 | (data[i * 2 + 1] & 0xff));
//        short[] shorts = new short[data.length/2];
//       ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts);
        return retVal;
    }

    private String license = "";

    private void loadsetup() {
        AssetManager assetManager = getAssets();
        InputStream inputStream = null;

        try {
            String prefix = "license key=\"";
            String suffix = "\"";
            String pattern = prefix + "(.+?)" + suffix;
            Pattern p = Pattern.compile(pattern);

            inputStream = assetManager.open("license.txt");
            ArrayList<String> data = new ArrayList<String>();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            try {
                while (true) {
                    String line = reader.readLine();
                    if (line == null || line.isEmpty())
                        break;
                    Matcher m = p.matcher(line);
                    if (m.find()) {
                        license = line.substring(m.regionStart() + prefix.length(), m.regionEnd() - suffix.length());
                        break;
                    }
                }
            } catch (IOException e) {

            }
            inputStream.close();
        } catch (IOException e) {
            Log.e(TAG, "Cant load the license file");
        }

        try {
            inputStream = assetManager.open("setupinfo.txt");
            ArrayList<String> data = new ArrayList<String>();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            try {
                while (true) {
                    String line = reader.readLine();
                    if (line == null || line.isEmpty()) {
                        break;
                    }
                    data.add(line);
                }
            } catch (IOException e) {

            }
            inputStream.close();
//
//            for (int i = 0; i < data.size(); ++i) {
//                enableCheckBox(data.get(i));
//            }

        } catch (IOException e) {
            Log.e(TAG, "Cant load the setup file");
        }

        Log.d(TAG, "Finished reading data");
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }


    private void showTipsDialog() {
//        if (tipsDialog == null) {
//            tipsDialog = new Dialog(this);
//            tipsDialog.setContentView(R.layout.dialog_startecg_tips);
//            tipsDialog.findViewById(R.id.bt_startecg_ok).setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    tipsDialog.dismiss();
//                }
//            });
//            tipsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//            ViewGroup.LayoutParams lay = tipsDialog.getWindow().getAttributes();
//            lay.width = ScreenUtils.getScreenWidth(getActivity());
//        }
//        tipsDialog.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbinder.unbind();
        unSubscribe(subscription);
    }

    protected void unSubscribe(Disposable subscription) {
        if (subscription != null && !subscription.isDisposed()) {
            subscription.dispose();
        }
    }

    @OnClick({R.id.iv_change_display, R.id.bt_startEcg})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_change_display:
                switchToLandscape();
                break;
            case R.id.bt_startEcg:
                startMeasure();
                break;
        }

    }

    private void startMeasure() {
        changeChartVisibility(true);
        if (BleManager.getInstance().isConnected()) {
            BleManager.getInstance().writeValue(enableEcgPPg(4));
            nskAlgoSdk.NskAlgoStart(false);
            //startEcgTimer();
        }
    }

    private static byte[] enableEcgPPg(int level) {
        byte[] value = new byte[16];
        value[0] = (byte) 0x99;
        value[1] = (byte) level;
        crcValue(value);
        return value;
    }

    public void changeChartVisibility(boolean start) {

        if (!start) {
            clearEcgPPgDatas();
            unSubscribe(ecgDisposable);
        }
        tvEcg.setVisibility(start ? View.VISIBLE : View.INVISIBLE);
        tvPpg.setVisibility(start ? View.VISIBLE : View.INVISIBLE);
        ivChangeDisplay.setVisibility(start ? View.VISIBLE : View.INVISIBLE);
        EcgGraphicView.setVisibility(start ? View.VISIBLE : View.INVISIBLE);
        lineChartViewPpg.setVisibility(start ? View.VISIBLE : View.INVISIBLE);
        btStartEcg.setVisibility(start ? View.INVISIBLE : View.VISIBLE);
    }

    private void clearEcgPPgDatas() {
        queuePpg.clear();
        queueEcg.clear();
        textViewEcgHrv.setText("--");
        textViewEcgHr.setText("--");

    }

    private void switchToLandscape() {

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

}
