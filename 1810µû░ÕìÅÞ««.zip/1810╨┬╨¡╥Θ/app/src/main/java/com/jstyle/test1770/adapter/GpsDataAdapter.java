package com.jstyle.test1770.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.jstyle.blesdk.constant.DeviceKey;
import com.jstyle.test1770.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Administrator on 2018/4/26.
 */

public class GpsDataAdapter extends RecyclerView.Adapter {
    List<Map<String, String>> list = new ArrayList<>();

    public void setData(List<Map<String, String>> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_activitymodedata, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ViewHolder viewHolder = (ViewHolder) holder;
        Map<String, String> map = list.get(position);
        String date = map.get(DeviceKey.Date);
        String Latitude = map.get(DeviceKey.Latitude);
        String Longitude = map.get(DeviceKey.Longitude);
        String[] LatitudeStringArray =Latitude.split(",");
        String[] LongitudeStringArray =Longitude.split(",");
        StringBuffer stringBuffer=new StringBuffer();
        for (int i = 0; i < LatitudeStringArray.length; i++) {
            stringBuffer.append(LatitudeStringArray[i]).append(",")
                    .append(LongitudeStringArray[i]).append(";");
        }
        viewHolder.textTotalDate.setText(date);
        viewHolder.textActivityModeData.setText(stringBuffer.toString());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.text_totalDate)
        TextView textTotalDate;
        @BindView(R.id.text_activityModeData)
        TextView textActivityModeData;


        ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}
