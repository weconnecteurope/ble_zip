package com.jstyle.test1770.Util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;


import com.jstyle.test1770.R;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lecho.lib.hellocharts.gesture.ContainerScrollType;
import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.model.ArcValue;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.BpValue;
import lecho.lib.hellocharts.model.Column;
import lecho.lib.hellocharts.model.ColumnChartData;
import lecho.lib.hellocharts.model.ColumnValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.SelectedValue;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.AbstractChartView;
import lecho.lib.hellocharts.view.PieChartView;

/**
 * Created by Administrator on 2017/5/19.
 */

public class ChartDataUtil {
    private static final String TAG = "ChartDataUtil";


//    public static void initChartView(AbstractChartView chart, float top, float bottom, float left, float right) {
//        Viewport viewport = chart.getCurrentViewport();
//        viewport.top = top;
//        viewport.bottom = bottom;
//        viewport.left = left;
//        viewport.right = right;
//        chart.setContainerScrollEnabled(true, ContainerScrollType.HORIZONTAL_IN_ScrollView);
//        chart.setViewportCalculationEnabled(false);
//        chart.setMaximumViewport(viewport);
//        chart.setZoomType(ZoomType.HORIZONTAL);
//        chart.setCurrentViewport(viewport, false);
//        // chart.setZoomEnabled(false);
//    }

    public static void initDataChartView(AbstractChartView chart, float left, float top, float right, float bottom) {
        Viewport viewport = chart.getCurrentViewport();
        viewport.top = top;
        viewport.bottom = bottom;
        viewport.left = left;
        viewport.right = right;
        chart.setScrollEnabled(true);
        chart.setContainerScrollEnabled(true, ContainerScrollType.VERTICAL);
        chart.setViewportCalculationEnabled(false);
        chart.setMaximumViewport(viewport);
        chart.setZoomType(ZoomType.HORIZONTAL_AND_VERTICAL);
        chart.setCurrentViewport(viewport, false);
    }











    public static LineChartData getEcgLineChartData(Context context, List<Integer> queue, int color) {
        LineChartData lineChartData = new LineChartData();
        List<Line> listLines = new ArrayList<>();
        Line line = new Line();
        List<PointValue> listPoint = new ArrayList<>();
        List<AxisValue> axisValues = new ArrayList<>();
        Axis axisX = new Axis();
        for (int i = 0; i < 4; i++) {
            axisValues.add(new AxisValue(i * 512).setLabel(String.valueOf(i  + "s").toCharArray()));
        }
        axisX.setValues(axisValues);
        for (int i = 0; i < queue.size(); i++) {
            int data = queue.get(i);
            PointValue pointValue = new PointValue();
            pointValue.set(i, data);
            listPoint.add(pointValue);
        }
        line.setValues(listPoint);
        line.setColor(color);
        line.setCubic(true);
        line.setStrokeWidth(2);
        line.setHasPoints(false);
        listLines.add(line);
        lineChartData.setLines(listLines);
        Bitmap bitmap=BitmapFactory.decodeResource(context.getResources(), R.drawable.bg_ecg_h);
        lineChartData.setBitmap(bitmap);
        lineChartData.setAxisXBottom(axisX.setHasAxisLines(false));
        return lineChartData;
    }
    public static LineChartData getPpgLineChartData(Context context, List<Integer> queue, int color) {
        LineChartData lineChartData = new LineChartData();
        List<Line> listLines = new ArrayList<>();
        Line line = new Line();
        List<PointValue> listPoint = new ArrayList<>();
        List<AxisValue> axisValues = new ArrayList<>();
        Axis axisX = new Axis();
        for (int i = 0; i < 7; i++) {
            axisValues.add(new AxisValue(i * 200).setLabel(String.valueOf(i  + "s").toCharArray()));
        }
        axisX.setValues(axisValues);
        for (int i = 0; i < queue.size(); i++) {
            int data = queue.get(i);
            PointValue pointValue = new PointValue();
            pointValue.set(i, data);
            listPoint.add(pointValue);
        }
        line.setValues(listPoint);
        line.setColor(color);
        line.setCubic(true);
        line.setStrokeWidth(1);
        line.setHasPoints(false);
        listLines.add(line);
        lineChartData.setLines(listLines);
        Bitmap bitmap=BitmapFactory.decodeResource(context.getResources(),R.drawable.bg_ecg_h);
        lineChartData.setBitmap(bitmap);
        lineChartData.setAxisXBottom(axisX.setHasAxisLines(false));
        return lineChartData;
    }

}
