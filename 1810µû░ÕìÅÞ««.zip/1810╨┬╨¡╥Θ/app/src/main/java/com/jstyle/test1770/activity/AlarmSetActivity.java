package com.jstyle.test1770.activity;

import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;

import com.jstyle.blesdk.Util.BleSDK;
import com.jstyle.blesdk.Util.ResolveUtil;
import com.jstyle.blesdk.cmdenum.SendCmdState;
import com.jstyle.blesdk.model.Clock;
import com.jstyle.test1770.R;
import com.jstyle.test1770.adapter.ClockWeekAdapter;


import java.util.List;

import butterknife.BindArray;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class AlarmSetActivity extends BaseActivity {

    @BindView(R.id.edit_clock_content)
    EditText editClockContent;
    @BindView(R.id.timePicker_clock_set)
    TimePicker timePickerClockSet;
    @BindView(R.id.radio_disable)
    RadioButton radioDisable;
    @BindView(R.id.radio_normal)
    RadioButton radioNormal;
    @BindView(R.id.radio_Medicine)
    RadioButton radioMedicine;
    @BindView(R.id.radio_Drink)
    RadioButton radioDrink;
    @BindView(R.id.radioGroup_gender)
    RadioGroup radioGroupGender;
    @BindView(R.id.RecyclerView_alarm_set)
    RecyclerView RecyclerViewAlarmSet;
    @BindView(R.id.bt_clock_save)
    Button btClockSave;
    @BindArray(R.array.weekarray)
    String[]weekArray;
    private Clock clock;
    private ClockWeekAdapter clockWeekAdapter;
    private int clockId;
    private List<Clock> clockList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clock_set);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        clockId = getIntent().getIntExtra("clockid", -1);
        clockList = (List<Clock>) getIntent().getSerializableExtra(AlarmListActivity.KEY_CLOCK_LIST);
        clock= clockList.get(clockId);
        if(clock==null)return;
        String content=clock.getContent();
        int hour=clock.getHour();
        int min=clock.getMinute();
        int type=clock.getType();
        int week=clock.getWeek();
        initGroup(type);
        initWeek(week);

        editClockContent.setText(content);
        timePickerClockSet.setIs24HourView(true);
        timePickerClockSet.setCurrentHour(hour);
        timePickerClockSet.setCurrentMinute(min);
    }

    private void initWeek(int week) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        RecyclerViewAlarmSet.setLayoutManager(linearLayoutManager);
        int[]positions=new int[7];
        String weekString= ResolveUtil.getByteString((byte) week);
        String[]weekArrs=weekString.split("-");
        for(int i=0;i<7;i++){
            if(weekArrs[i].equals("1")){
                positions[i]=1;
            }
        }
        clockWeekAdapter = new ClockWeekAdapter(weekArray,positions);
        RecyclerViewAlarmSet.setAdapter(clockWeekAdapter);
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        RecyclerViewAlarmSet.addItemDecoration(dividerItemDecoration);
    }

    private void initGroup(int type) {
        int id=R.id.radio_disable;
        switch (type){
            case 0:
                id=R.id.radio_disable;
                break;
            case 1:
                id=R.id.radio_normal;
                break;
            case 2:
                id=R.id.radio_Medicine;
                break;
            case 3:
                id=R.id.radio_Drink;
                break;
        }
        radioGroupGender.check(id);
    }

    private int getClockType(){
        int id=0;
        switch (radioGroupGender.getCheckedRadioButtonId()){
            case R.id.radio_disable:
                id=0;
                break;
            case R.id.radio_normal:
                id=1;
                break;
            case R.id.radio_Medicine:
                id=2;
                break;
            case R.id.radio_Drink:
                id=3;
                break;
        }
        return id;
    }
    private int getCheckWeek(){
        int week=0;
        int[]positions=clockWeekAdapter.getCheckWeek();
        for(int i=0;i<7;i++){
            if(positions[i]==1)    week += Math.pow(2, i);
        }
        return week;
    }
    @OnClick(R.id.bt_clock_save)
    public void onViewClicked() {
        String content=editClockContent.getText().toString();
        int hour=timePickerClockSet.getCurrentHour();
        int min=timePickerClockSet.getCurrentMinute();
        int type=getClockType();
        int week=getCheckWeek();
        if(TextUtils.isEmpty(content)){
            clock.setContent("");
        }else {clock.setContent(content);
        }

        clock.setHour(hour);
        clock.setMinute(min);
        clock.setType(type);
        clock.setWeek((byte) week);

        byte[] value = BleSDK.setClockData(clockList);
        int maxLength = MainActivity.phoneDataLength;
        if (value.length > maxLength) {
            int size = maxLength / 38;//一个包最多发的闹钟个数
            int length = size * 38;//最大闹钟数占用的字节
            int count = value.length % length == 0 ? value.length / length : value.length / length + 1;//需要多少个包来发送
            for (int i = 0; i < count; i++) {
                int end = length * (i + 1);
                int endLength = length;
                if (end >= value.length) endLength = value.length - length * i;
                byte[] data = new byte[endLength];
                System.arraycopy(value, length * i, data, 0, endLength);
               offerData(data);
            }
            offerData();
        } else {
            sendValue(value);
        }
        setResult(RESULT_OK);
    }

}
