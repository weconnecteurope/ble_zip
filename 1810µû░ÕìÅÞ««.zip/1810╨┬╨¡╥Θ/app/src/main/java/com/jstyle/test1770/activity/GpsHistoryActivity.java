package com.jstyle.test1770.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.jstyle.blesdk.Util.BleSDK;
import com.jstyle.blesdk.constant.BleConst;
import com.jstyle.blesdk.constant.DeviceKey;
import com.jstyle.test1770.R;
import com.jstyle.test1770.adapter.ActivityModeDataAdapter;
import com.jstyle.test1770.adapter.GpsDataAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class GpsHistoryActivity extends BaseActivity {

    @BindView(R.id.bt_getData)
    Button btGetData;
    @BindView(R.id.bt_deleteData)
    Button btDeleteData;
    @BindView(R.id.RecyclerView_exerciseHistory)
    RecyclerView RecyclerViewExerciseHistory;
    int ModeStart=0;
    int ModeContinue=2;
    int ModeDelete=0x99;
    private List<Map<String, String>> list;
    private GpsDataAdapter gpsDataAdapter;
    private int dataCount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps_history);
        ButterKnife.bind(this);
        init();
    }
    private void init() {
        list=new ArrayList<>();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        RecyclerViewExerciseHistory.setLayoutManager(linearLayoutManager);
        gpsDataAdapter = new GpsDataAdapter();
        RecyclerViewExerciseHistory.setAdapter(gpsDataAdapter);
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        RecyclerViewExerciseHistory.addItemDecoration(dividerItemDecoration);
    }
    @OnClick({R.id.bt_getData, R.id.bt_deleteData})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.bt_getData:
                getData(ModeStart);
                break;
            case R.id.bt_deleteData:
                getData(ModeDelete);
                break;
        }
    }
    private void getData(int mode){
        showProgressDialog("同步数据");
        sendValue(BleSDK.GetGPSDataWithMode(mode));
    }

    @Override
    public void dataCallback(Map<String, Object> maps) {
        super.dataCallback(maps);
        String dataType= getDataType(maps);
        boolean finish=getEnd(maps);
        switch (dataType){
            case BleConst.GetGPSData:
                list.addAll((List<Map<String,String>>)maps.get(DeviceKey.Data));
                dataCount++;
                if(finish){
                    dataCount=0;
                    disMissProgressDialog();
                    gpsDataAdapter.setData(list);
                }
                if(dataCount==50){
                    dataCount=0;
                    if(finish){
                        disMissProgressDialog();
                        gpsDataAdapter.setData(list);
                    }else{
                        getData(ModeContinue);
                    }
                }
                break;
        }
    }
}
