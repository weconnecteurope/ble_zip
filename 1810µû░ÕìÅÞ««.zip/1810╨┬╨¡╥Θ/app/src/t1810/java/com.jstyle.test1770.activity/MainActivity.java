package com.jstyle.test1770.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.jstyle.blesdk.Util.BleSDK;
import com.jstyle.blesdk.constant.BleConst;
import com.jstyle.blesdk.constant.DeviceKey;
import com.jstyle.test1770.R;
import com.jstyle.test1770.Util.BleData;
import com.jstyle.test1770.Util.RxBus;
import com.jstyle.test1770.adapter.MainAdapter;
import com.jstyle.test1770.ble.BleManager;
import com.jstyle.test1770.ble.BleService;


import java.util.Map;

import butterknife.BindArray;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends BaseActivity implements MainAdapter.onItemClickListener {
    private static final String TAG = "MainActivity";
    @BindView(R.id.main_recyclerview)
    RecyclerView mainRecyclerview;
    @BindArray(R.array.item_options)
    String[] options;
    @BindView(R.id.BT_CONNECT)
    Button btConnect;
    @BindView(R.id.button_startreal)
    Button buttonStartreal;
    @BindView(R.id.textView_step)
    TextView textViewStep;
    @BindView(R.id.textView_cal)
    TextView textViewCal;
    @BindView(R.id.textView_distance)
    TextView textViewDistance;
    @BindView(R.id.textView_time)
    TextView textViewTime;
    @BindView(R.id.textView1)
    TextView textView1;
    @BindView(R.id.textView_heartValue)
    TextView textViewHeartValue;
    private ProgressDialog progressDialog;
    private Disposable subscription;
    private String address;
    boolean isStartReal;
    public static int phoneDataLength = 200;//手机一个包能发送的最多数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        init();
        connectDevice();
    }

    private void connectDevice() {
        address = getIntent().getStringExtra("address");
        if (TextUtils.isEmpty(address)) {
            Log.i(TAG, "onCreate: address null ");
            return;
        }
        Log.i(TAG, "onCreate: ");
        BleManager.getInstance().connectDevice(address);
        showConnectDialog();
    }

    private void showConnectDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.connectting));
        // progressDialog.setCancelable(false);
        if (!progressDialog.isShowing()) progressDialog.show();

    }

    private void dissMissDialog() {
        if (progressDialog != null && progressDialog.isShowing()) progressDialog.dismiss();
        ;
    }

    private void init() {

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        mainRecyclerview.setLayoutManager(gridLayoutManager);
        final MainAdapter mainAdapter = new MainAdapter(options, this);
        mainRecyclerview.setAdapter(mainAdapter);
        subscription = RxBus.getInstance().toObservable(BleData.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<BleData>() {
            @Override
            public void accept(BleData bleData) throws Exception {
                String action = bleData.getAction();
                if (action.equals(BleService.ACTION_GATT_onDescriptorWrite)) {
                    mainAdapter.setEnable(true);
                    btConnect.setEnabled(false);
                    buttonStartreal.setEnabled(true);
                    dissMissDialog();
                } else if (action.equals(BleService.ACTION_GATT_DISCONNECTED)) {
                    mainAdapter.setEnable(false);
                    btConnect.setEnabled(true);
                    buttonStartreal.setEnabled(false);
                    isStartReal = false;
                    dissMissDialog();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unsubscribe();
        if (BleManager.getInstance().isConnected()) BleManager.getInstance().disconnectDevice();
    }

    private void unsubscribe() {
        if (subscription != null && !subscription.isDisposed()) {
            subscription.dispose();
            Log.i(TAG, "unSubscribe: ");
        }
    }

    @OnClick({R.id.BT_CONNECT, R.id.button_startreal})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.BT_CONNECT:
                connectDevice();
                break;
            case R.id.button_startreal:
                isStartReal = !isStartReal;
                buttonStartreal.setText(isStartReal ? "Stop" : "Start");

                sendValue(BleSDK.RealTimeStep(isStartReal));
                break;
        }

    }

    @Override
    public void onItemClick(int position) {
        Intent intent;
        switch (position) {
            case 0:
                intent = new Intent(MainActivity.this, BasicActivity.class);
                startActivity(intent);
                break;
            case 1:
                intent = new Intent(MainActivity.this, DeviceInfoActivity.class);
                startActivity(intent);
                break;
            case 2:
                intent = new Intent(MainActivity.this, DetailDataActivity.class);
                startActivity(intent);
                break;
            case 3:
                intent = new Intent(MainActivity.this, HeartRateInfoActivity.class);
                startActivity(intent);
                break;
            case 4:
                intent = new Intent(MainActivity.this, TotalDataActivity.class);
                startActivity(intent);
                break;
            case 5:
                intent = new Intent(MainActivity.this, AlarmListActivity.class);
                startActivity(intent);
                break;
            case 6:
                intent = new Intent(MainActivity.this, HeartRateSetActivity.class);
                startActivity(intent);
                break;
            case 7:
                intent = new Intent(MainActivity.this, ActivityAlarmSetActivity.class);
                startActivity(intent);
                break;
            case 8:
                intent = new Intent(MainActivity.this, NotifyActivity.class);
                startActivity(intent);
                break;
            case 9:
                intent = new Intent(MainActivity.this, SetGoalActivity.class);
                startActivity(intent);
                break;
//            case 10:
//                GetData getData=new GetData();
//                getData.setDataNum(1);
//                sendData(SendCmdState.GET_GPS_DATA,getData);
////                intent = new Intent(MainActivity.this, ActivitySetActivity.class);
////                startActivity(intent);
//                break;
//            case 11:
//                GetData getData2=new GetData();
//                getData2.setDataNum(1);
//               sendData(SendCmdState.GET_SPORTMODEL_DATA,getData2);
////                intent = new Intent(MainActivity.this, StepTestActivity.class);
////                startActivity(intent);
//                break;


            default:
                break;
        }

    }

    @Override
    public void dataCallback(Map<String, Object> map) {
        super.dataCallback(map);
        String dataType= getDataType(map);

        switch (dataType) {
            case BleConst.RealTimeStep:
                Map<String,String>maps= getData(map);
                String step = maps.get(DeviceKey.Step);
                String cal = maps.get(DeviceKey.Calories);
                String distance = maps.get(DeviceKey.Distance);
                String time = maps.get(DeviceKey.ExerciseMinutes);
                String heart = maps.get(DeviceKey.HeartRate);
                textViewCal.setText(cal);
                textViewStep.setText(step);
                textViewDistance.setText(distance);
                textViewTime.setText(time);
                textViewHeartValue.setText(heart);
                break;
            case BleConst.TakePhotoMode:
                showDialogInfo(BleConst.TakePhotoMode);
                break;
            case BleConst.FindMobilePhoneMode:
                showDialogInfo(BleConst.FindMobilePhoneMode);
                break;
            case BleConst.RejectTelMode:
                showDialogInfo(BleConst.RejectTelMode);
                break;
            case BleConst.TelMode:
                showDialogInfo(BleConst.TelMode);
                break;


        }
    }
}
