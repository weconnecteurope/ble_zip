package lecho.lib.hellocharts.provider;

import lecho.lib.hellocharts.model.ComboLineColumnChartData;

public interface ComboLineColumnChartDataProvider {

	public ComboLineColumnChartData getComboLineColumnChartData();

	public void setComboLineColumnChartData(ComboLineColumnChartData data);

}
