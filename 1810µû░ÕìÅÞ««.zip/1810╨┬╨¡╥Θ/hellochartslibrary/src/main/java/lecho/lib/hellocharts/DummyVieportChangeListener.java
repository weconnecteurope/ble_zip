package lecho.lib.hellocharts;

import lecho.lib.hellocharts.model.Viewport;

public class DummyVieportChangeListener implements ViewportChangeListener {

	@Override
	public void onViewportChanged(Viewport viewport) {
		// Do nothing
	}
}
